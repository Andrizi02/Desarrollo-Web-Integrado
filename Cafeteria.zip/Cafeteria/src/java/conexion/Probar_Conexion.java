package conexion;

public class Probar_Conexion {
    public static void main(String[] args) {
        Conexion dbc = new Conexion();
        dbc.conectar();
    }
}
