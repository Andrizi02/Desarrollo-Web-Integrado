
package Implementacion;

import java.io.Serializable;
import java.util.Date;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class PedidoBean implements Serializable {

    private String nombreCliente;
    private String correo;
    private String producto;
    private int cantidad;
    private Date fechaPedido;

    // Getters and Setters
    public String getNombreCliente() { return nombreCliente; }
    public void setNombreCliente(String nombreCliente) { this.nombreCliente = nombreCliente; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getProducto() { return producto; }
    public void setProducto(String producto) { this.producto = producto; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public Date getFechaPedido() { return fechaPedido; }
    public void setFechaPedido(Date fechaPedido) { this.fechaPedido = fechaPedido; }

    // Métodos de acción
    public String realizarPedido() {
        System.out.println("Pedido recibido:");
        System.out.println("Cliente: " + nombreCliente);
        System.out.println("Correo: " + correo);
        System.out.println("Producto: " + producto);
        System.out.println("Cantidad: " + cantidad);
        fechaPedido = new Date();
        return "confirmacion.xhtml";
    }

    public void limpiarFormulario() {
        nombreCliente = "";
        correo = "";
        producto = "";
        cantidad = 0;
        fechaPedido = null;
    }
}
