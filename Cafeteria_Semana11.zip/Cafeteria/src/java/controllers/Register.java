package controllers;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Register {
    public static boolean registrarPedido(String cliente, String producto, String cantidad) {
            Connection con = null;
            PreparedStatement preparestat = null;
            boolean registrado = false;
        
        try {
            con = Conexion.conectar();
            String sql = "INSERT INTO orders (cliente, producto, cantidad) VALUES (?, ?, ?)";
            preparestat = con.prepareStatement(sql);
            preparestat.setString(1, cliente);
            preparestat.setString(2, producto);
            preparestat.setString(3, cantidad);
            
            int resultado = preparestat.executeUpdate();
            registrado = (resultado > 0);
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparestat != null) preparestat.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return registrado;
    }
}